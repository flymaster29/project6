﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

public class NodeExample : EditorWindow {

    public List<NodeBaseClass> myNodes = new List<NodeBaseClass>();
	public static Spool mySpool;
    public int nodeAttachID = -1;
	public bool preAttach = false;
    [MenuItem("Node Editor/ Editor")]
	public static void showWindow()
    {
        GetWindow<NodeExample>();
    }

    public void OnGUI()
    {
		//myNodes. = 

		EditorGUI.BeginChangeCheck ();
		mySpool = (Spool)EditorGUILayout.ObjectField (mySpool, typeof(Spool), false);
		if (EditorGUI.EndChangeCheck ()) {
			myNodes.Clear ();
			if (mySpool != null) {
				for (int i = 0; i < mySpool.stitchCollection.Length; i++) {
					myNodes.Add(new StitchNode(new Rect(100*i, 20, 100, 100), i, mySpool.stitchCollection[i]));
					myNodes[myNodes.Count-1].closeFunction += RemoveNode;
					myNodes[myNodes.Count - 1].nodeEditor = this;
				}
			}
		}

		if(mySpool != null) {
			for (int i = 0; i < mySpool.stitchCollection.Length; i++)
			{
				for (int j = 0; j < mySpool.stitchCollection[i].yarns.Length; j++)
				{

					if (mySpool.stitchCollection [i].yarns [j].choiceStitch != null) {
						DrawNodeCurve(myNodes[i].rect, myNodes[mySpool.stitchCollection[i].yarns[j].choiceStitch.stitchID].rect);
						if (!preAttach) {
							myNodes [i].AttachComplete (myNodes [mySpool.stitchCollection [i].yarns [j].choiceStitch.stitchID]);

						}
					}

				}
			}
			preAttach = true;
			if (GUILayout.Button("Node A"))
			{

				List<Stitch> temp1 = new List<Stitch> (mySpool.stitchCollection);
				foreach (Stitch element in temp1) {
					Debug.Log (element.stitchName);
				}

				Stitch theOriginal = (Stitch)AssetDatabase.LoadAssetAtPath ("Assets/MyPlayStory/newStitch.asset", typeof(Stitch));
				string theOriginalPath = AssetDatabase.GetAssetPath (theOriginal);
				string theCopyPath = "Assets/MyPlayStory/Stitch" + (temp1.Count + 1) + ".asset";
				//AssetDatabase.CreateAsset(temp2, "Assets/MyPlayStory/stich" + temp1.Count + ".asset");
				AssetDatabase.CopyAsset(theOriginalPath, theCopyPath);
				Stitch theCopy = (Stitch)AssetDatabase.LoadAssetAtPath (theCopyPath, typeof(Stitch));
				AssetDatabase.SaveAssets ();
				theCopy.stitchID = temp1.Count;
				theCopy.stitchName = "Scene" + (temp1.Count + 1);
				temp1.Add (theCopy);

				mySpool.stitchCollection = temp1.ToArray ();


				myNodes.Add(new StitchNode(new Rect(10, 40, 100, 100), myNodes.Count, mySpool.stitchCollection[myNodes.Count]));
				//myNodes.Add(new NodeA(new Rect(10,40,100,100),myNodes.Count));
				myNodes[myNodes.Count-1].closeFunction += RemoveNode;
				myNodes[myNodes.Count - 1].nodeEditor = this;

			}
			/*
			List<Stitch> temp = new List<Stitch> (mySpool.stitchCollection);
			foreach (Stitch element in temp) {
				Debug.Log (element.stitchName);
			}
			*/

		}



       BeginWindows();
        for(int i = 0; i < myNodes.Count; i++)
        {
			myNodes[i].rect = GUI.Window(i, myNodes[i].rect, myNodes[i].DrawGUI, mySpool.stitchCollection[i].stitchName);
        }
        EndWindows();


       for (int i = 0; i < myNodes.Count; i++)
        {
			 if (GUI.Button(new Rect(myNodes[i].rect.xMax - 10, myNodes[i].rect.y + myNodes[i].rect.height / 2, 20, 20), "+"))
            {
                BeginAttachment(i);
            }

            if (GUI.Button(new Rect(myNodes[i].rect.xMin - 10, myNodes[i].rect.y + myNodes[i].rect.height / 2, 20, 20), "O"))
            {
                EndAttachment(i);
            }
        }
        
    }

    public void RemoveNode(int id)
    {
		//remove all linked nodes
		//delete current node
		//remove all yarn references to deleted node
		for (int i = 0; i < myNodes.Count; i++)
        {
            myNodes[i].linkedNodes.RemoveAll(item => item.id == id);
			//mySpool.stitchCollection[i]/

        }
		List<Stitch> temp1 = new List<Stitch> (mySpool.stitchCollection);
		string deleteNodeName = temp1 [id].ToString ();
		Debug.Log ("Location right before delete yarn foreach");
		foreach(Yarn eYarn in temp1[id].yarns) {
			Debug.Log ("Made it into delete yarn foreach");
			List<Yarn> tempYarns = new List<Yarn> (temp1[id].yarns);
			Debug.Log("Deleting Yarn: " + eYarn.choiceString + "from " + deleteNodeName);
			tempYarns.Remove (eYarn);
			temp1[id].yarns = tempYarns.ToArray ();
		}
		AssetDatabase.DeleteAsset (AssetDatabase.GetAssetPath (temp1 [id]));
		temp1.RemoveAt (id);
		int stitchCounter = 0;
		foreach (Stitch eStich in temp1) {
			eStich.stitchID = stitchCounter;
			eStich.stitchName = "Scene" + (stitchCounter + 1);
			Debug.Log ("Made it into Stitch foreach");
			int yarnCounter = 0;
			foreach (Yarn eYarn in eStich.yarns) {
				Debug.Log ("Made it into Yarn foreach");
				Debug.Log (" Yarn Name: " + eYarn.choiceStitch.ToString ());
				//if (eYarn.choiceStitch.ToString () == deleteNodeName || eYarn.choiceStitch.ToString () == null) {
				if (eYarn.choiceStitch == null) {
					Debug.Log ("Made it into Delete Yarn If");
					List<Yarn> tempYarns = new List<Yarn> (eStich.yarns);
					tempYarns.RemoveAt (yarnCounter);
					eStich.yarns = tempYarns.ToArray ();
				}
				yarnCounter++;
			}
			stitchCounter++;
		}

		Debug.Log ("DeleteNodeNAme: " + deleteNodeName);
		//Stitch toRemove = temp1[id];
		//AssetDatabase.DeleteAsset(AssetDatabase.GetAssetPath(temp1[id]));


		mySpool.stitchCollection = temp1.ToArray ();
        myNodes.RemoveAt(id);
        UpdateNodeIDs();
    }

    public void UpdateNodeIDs()
    {
        for(int i = 0; i < myNodes.Count; i++)
        {
            myNodes[i].ReassignID(i);
        }
    }

    public void BeginAttachment(int winID)
    {
        nodeAttachID = winID;
    }
        
    public void EndAttachment(int winID)
    {
		if (nodeAttachID > -1)
        {
			myNodes[nodeAttachID].AttachComplete(myNodes[winID], mySpool.stitchCollection[winID]);
        }
        nodeAttachID = -1;
    }

    void DrawNodeCurve(Rect start, Rect end)
    {
        Vector3 startPos = new Vector3(start.x + start.width, start.y + (start.height / 2)+10, 0);
        Vector3 endPos = new Vector3(end.x, end.y + (end.height / 2)+ 10, 0);
        Vector3 startTan = startPos + Vector3.right * 100;
        Vector3 endTan = endPos + Vector3.left * 100;
        Color shadowCol = new Color(0, 0, 0, 0.06f);

       
        Handles.DrawBezier(startPos, endPos, startTan, endTan, Color.black, null, 5);
    }

}
