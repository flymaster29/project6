﻿using UnityEngine;
using UnityEditor;

public class AttachmentError : EditorWindow
{
	public static string message;
	public static void blahblah(string pMessage) {
		message = pMessage;
		AttachmentError window = EditorWindow.GetWindow<AttachmentError> ();
		window.position = new Rect(Screen.width / 2, Screen.height / 2, 200, 200);
	}

	void OnGUI()
	{
		EditorGUILayout.LabelField(message , EditorStyles.wordWrappedLabel);
		GUILayout.Space(10);
		if (GUILayout.Button("Okay!")) this.Close();
	}

}