﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StitchNode : NodeBaseClass {

	public Stitch myStitch;
	public StitchNode (Rect r, int ID, Stitch stitch) : base(r,ID)
	{
		myStitch = stitch;
	}

	public override void DrawGUI(int winID)
	{
		
		/*
		GUILayout.Label(id.ToString());
		//GUILayout.Label("Node : A");
		foreach(NodeBaseClass n in linkedNodes)
		{
			GUILayout.Label("Linked to:  " + n.id);
		}
		*/

		BaseDraw();
	}

	public override void AttachComplete(NodeBaseClass winID, Stitch stitch = null)
	{
		if(!base.linkedNodes.Contains(winID)) {
			linkedNodes.Add(winID);
			if (stitch != null) {
				Debug.Log ("Attempt to Add Yarn");
				AttachYarn (stitch);
			}

		} else {
			base.ErrorMessage ("connecting to node");
		}

		//base.linkedNodes.Add(winID);
	}
		
	void AttachYarn(Stitch stitch) {
		Yarn temp;
		int getID;
		List<Yarn> tempYarns = new List<Yarn> (myStitch.yarns);
		tempYarns.Add (new Yarn());
		getID = tempYarns.Count;
		temp = tempYarns [getID - 1];
		temp.choiceStitch = stitch;
		temp.choiceString = "Go to " + (stitch.stitchID + 1) + "!";
		myStitch.yarns = tempYarns.ToArray ();
	}
}
