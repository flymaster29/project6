﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

public class EditStitch : EditorWindow {

	static Stitch toEdit;
	Vector2 scrollPos;

	public static string message;
	[MenuItem("Custom Tools/Enemy Tool %g")]
	public static void StitchEditor(Stitch stitch) {
		toEdit = stitch;
		Debug.Log("Editing Stich Named: " + toEdit.ToString());
		EditStitch window = EditorWindow.GetWindow<EditStitch> ();
		window.position = new Rect(Screen.width / 2, Screen.height / 2, 900, 900);
	}

	void OnGUI()
	{
		scrollPos = EditorGUILayout.BeginScrollView (scrollPos, GUILayout.Width(position.width), GUILayout.Height(position.height));

		EditorGUILayout.LabelField ("Spool Section");
		EditorGUI.indentLevel++;
		NodeExample.mySpool.storyName = EditorGUILayout.TextField ("Story Name", NodeExample.mySpool.storyName);
		NodeExample.mySpool.startStitch = (Stitch) EditorGUILayout.ObjectField("Start Stitch: ", NodeExample.mySpool.startStitch, typeof (Stitch), false);
		EditorGUI.indentLevel--;

		EditorGUILayout.LabelField ("Stitch Section");
		EditorGUI.indentLevel++;
		toEdit.stitchName = EditorGUILayout.TextField ("Stitch Name", toEdit.stitchName);
		toEdit.summary = EditorGUILayout.TextField ("Stitch Summary", toEdit.summary);
		toEdit.status = (Stitch.stitchStatus) EditorGUILayout.EnumPopup("Stitch Status", toEdit.status);
		toEdit.background = (Sprite) EditorGUILayout.ObjectField("Stitch Background", toEdit.background, typeof (Sprite), false);

		//EditorGUILayout.PropertyField (toEdit.performers, new GUIContent ("Ship Guns", "Example: Helium"), true);
		/*
		EditorGUILayout.serializedObject.Update ();
		GUIStyle myStyle = new GUIStyle (GUI.skin.GetStyle ("Label"));
		myStyle.alignment = TextAnchor.MiddleCenter;
		SerializedProperty myElem = Editor.serializedObject.FindProperty ("Performers");
		EditorGUILayout.PropertyField (myElem, new GUIContent ("Ship Guns", "Example: Helium"), true);
		Editor.serializedObject.ApplyModifiedProperties ();
		*/

		int performCount = 0;
		foreach (Performer ePerformer in toEdit.performers) {
			EditorGUILayout.Space ();
			EditorGUILayout.LabelField ("Performer: " + performCount);	
			EditorGUI.indentLevel++;
			ePerformer.actorSprite = (ActorSprite) EditorGUILayout.ObjectField("Actor Sprite", ePerformer.actorSprite, typeof (ActorSprite), false);
			ePerformer.transform = (RectTransform) EditorGUILayout.ObjectField("Transform", ePerformer.transform, typeof (RectTransform), false);
			ePerformer.order = EditorGUILayout.IntField("Order", ePerformer.order);
			EditorGUI.indentLevel--;
			performCount++;
		}

		int dialogCount = 0;
		foreach (Dialog eDialog in toEdit.dialogs) {
			EditorGUILayout.Space ();
			EditorGUILayout.LabelField ("Dialog: " + dialogCount);
			EditorGUI.indentLevel++;
			eDialog.nameShown = EditorGUILayout.TextField ("Name Shown", eDialog.nameShown);
			eDialog.textShown = EditorGUILayout.TextField ("Text Shown", eDialog.textShown);
			EditorGUI.indentLevel--;
			dialogCount++;
		}

		int yarnCount = 0;
		foreach (Yarn eYarn in toEdit.yarns) {
			EditorGUILayout.Space ();
			EditorGUILayout.LabelField ("Yarn: " + yarnCount);
			EditorGUI.indentLevel++;
			eYarn.choiceStitch = (Stitch) EditorGUILayout.ObjectField("Choice Stitch", eYarn.choiceStitch, typeof (Stitch), false);
			eYarn.choiceString = EditorGUILayout.TextField ("Choice String", eYarn.choiceString);
			EditorGUI.indentLevel--;
			yarnCount++;
		}


		EditorGUILayout.LabelField ("Information About Selected Stitch");
		EditorGUILayout.HelpBox (
			"Stitch ID: " + toEdit.stitchID + "\n" +
			"Stitch Name: " + toEdit.stitchName + "\n" +
			"Stitch Summary: " + toEdit.summary + "\n" +
			"Stitch Background: " + toEdit.background.texture + "\n" +
			getLists() +
			"Stitch Status: " + toEdit.status, 
			MessageType.Info);
		EditorGUI.indentLevel--;
		EditorGUILayout.EndScrollView ();
	}


	string getLists() {
		return getPerformers () + getDialogs () + getYarns ();
	}
	string getPerformers() {
		int tempCount = 0;
		string toReturn = "Stitch Performs: " + "\n";
		foreach (Performer ePerformer in toEdit.performers) {
			toReturn += "   " + "Performer" + tempCount + ":" + "\n";
			toReturn += "      " + "Actor Sprite: " + ePerformer.actorSprite.ToString () + "\n";
			toReturn += "      " + "Transform: " + ePerformer.transform.ToString () + "\n";
			toReturn += "      " + "Order: " + ePerformer.order + "\n";
			tempCount++;
		}

		return toReturn;
	}
	string getDialogs() {
		int tempCount = 0;
		string toReturn = "Stitch Dialogs: " + "\n";
		foreach (Dialog eDialog in toEdit.dialogs) {
			toReturn += "   " + "Dialog" + tempCount + ":" + "\n";
			toReturn += "      " + "Name Shown: " + eDialog.nameShown + "\n";
			toReturn += "      " + "Text Shown: " + eDialog.textShown + "\n";
			tempCount++;
		}

		return toReturn;
	}
	string getYarns() {
		int tempCount = 0;
		string toReturn = "Stitch Yarns: " + "\n";
		foreach (Yarn eYarn in toEdit.yarns) {
			toReturn += "   " + "Yarn" + tempCount + ":" + "\n";
			toReturn += "      " + "Choice Stitch: " + eYarn.choiceStitch.ToString() + "\n";
			toReturn += "      " + "Choice String: " + eYarn.choiceString + "\n";
			tempCount++;
		}

		return toReturn;
	}
}
